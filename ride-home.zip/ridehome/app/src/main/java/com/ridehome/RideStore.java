package com.ridehome;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Saves rides as small JSON files in the app's private storage. */
final class RideStore {
    private static final String TAG = "RideHome.Store";
    private static final String DIR = "rides";
    private static final String CHECKPOINT = "current.json";

    static final class Ride {
        String id;
        long startMs;
        int[] cadence = new int[0];
        int[] resistance = new int[0];
        int[] power = new int[0];

        int seconds() {
            return power.length;
        }

        int avgPower() {
            return avg(power);
        }

        int maxPower() {
            int m = 0;
            for (int v : power) {
                if (v > m) {
                    m = v;
                }
            }
            return m;
        }

        int avgCadence() {
            return avg(cadence);
        }

        int avgResistance() {
            return avg(resistance);
        }

        /** Total work in kilojoules (watts x seconds / 1000), like Peloton's "total output". */
        float totalKj() {
            long sum = 0;
            for (int v : power) {
                sum += v;
            }
            return sum / 1000f;
        }

        private static int avg(int[] a) {
            if (a.length == 0) {
                return 0;
            }
            long sum = 0;
            for (int v : a) {
                sum += v;
            }
            return Math.round((float) sum / a.length);
        }
    }

    private RideStore() {}

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), DIR);
        if (!d.exists()) {
            d.mkdirs();
        }
        return d;
    }

    /** Saves a finished ride. Each sample is {cadence, resistance, power}. */
    static String save(Context c, long startMs, List<int[]> samples) throws IOException, JSONException {
        String id = "ride_" + startMs + ".json";
        writeAtomic(new File(dir(c), id), toJson(startMs, samples));
        return id;
    }

    static List<Ride> loadAll(Context c) {
        List<Ride> out = new ArrayList<>();
        File[] files = dir(c).listFiles();
        if (files != null) {
            for (File f : files) {
                String name = f.getName();
                if (name.startsWith("ride_") && name.endsWith(".json")) {
                    try {
                        out.add(parse(name, readAll(f)));
                    } catch (Exception e) {
                        Log.w(TAG, "skipping unreadable ride " + name, e);
                    }
                }
            }
        }
        Collections.sort(out, new Comparator<Ride>() {
            @Override
            public int compare(Ride a, Ride b) {
                return Long.compare(b.startMs, a.startMs);
            }
        });
        return out;
    }

    static Ride load(Context c, String id) {
        try {
            return parse(id, readAll(new File(dir(c), id)));
        } catch (Exception e) {
            Log.w(TAG, "could not load " + id, e);
            return null;
        }
    }

    static boolean delete(Context c, String id) {
        return new File(dir(c), id).delete();
    }

    static void writeCheckpoint(Context c, long startMs, List<int[]> samples) {
        try {
            writeAtomic(new File(dir(c), CHECKPOINT), toJson(startMs, samples));
        } catch (Exception e) {
            Log.w(TAG, "checkpoint failed", e);
        }
    }

    static void clearCheckpoint(Context c) {
        new File(dir(c), CHECKPOINT).delete();
    }

    /** If the app died mid-ride, turns the last checkpoint into a saved ride. */
    static void recoverCheckpoint(Context c) {
        File f = new File(dir(c), CHECKPOINT);
        if (!f.exists()) {
            return;
        }
        try {
            Ride r = parse("checkpoint", readAll(f));
            if (r.seconds() >= Cfg.MIN_RIDE_SECONDS) {
                List<int[]> samples = new ArrayList<>();
                for (int i = 0; i < r.seconds(); i++) {
                    samples.add(new int[] {r.cadence[i], r.resistance[i], r.power[i]});
                }
                save(c, r.startMs, samples);
            }
        } catch (Exception e) {
            Log.w(TAG, "could not recover checkpoint", e);
        }
        f.delete();
    }

    private static String toJson(long startMs, List<int[]> samples) throws JSONException {
        JSONArray cadence = new JSONArray();
        JSONArray resistance = new JSONArray();
        JSONArray power = new JSONArray();
        for (int[] s : samples) {
            cadence.put(s[0]);
            resistance.put(s[1]);
            power.put(s[2]);
        }
        JSONObject o = new JSONObject();
        o.put("start", startMs);
        o.put("cadence", cadence);
        o.put("resistance", resistance);
        o.put("power", power);
        return o.toString();
    }

    private static Ride parse(String id, String json) throws JSONException {
        JSONObject o = new JSONObject(json);
        Ride r = new Ride();
        r.id = id;
        r.startMs = o.getLong("start");
        r.cadence = ints(o.getJSONArray("cadence"));
        r.resistance = ints(o.getJSONArray("resistance"));
        r.power = ints(o.getJSONArray("power"));
        return r;
    }

    private static int[] ints(JSONArray a) throws JSONException {
        int[] out = new int[a.length()];
        for (int i = 0; i < out.length; i++) {
            out[i] = a.getInt(i);
        }
        return out;
    }

    private static void writeAtomic(File target, String content) throws IOException {
        File tmp = new File(target.getParentFile(), target.getName() + ".tmp");
        FileOutputStream out = new FileOutputStream(tmp);
        try {
            out.write(content.getBytes("UTF-8"));
            out.getFD().sync();
        } finally {
            out.close();
        }
        if (!tmp.renameTo(target)) {
            target.delete();
            if (!tmp.renameTo(target)) {
                throw new IOException("could not write " + target.getName());
            }
        }
    }

    private static String readAll(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            return bos.toString("UTF-8");
        } finally {
            in.close();
        }
    }
}
