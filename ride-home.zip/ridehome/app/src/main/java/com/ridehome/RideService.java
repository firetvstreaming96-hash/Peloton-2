package com.ridehome;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Always-on background service. It reads the bike, decides when a ride has
 * started or stopped, records the ride, and shows or hides the metrics bar.
 */
public class RideService extends Service {
    static final String ACTION_RESTART_SENSOR = "com.ridehome.RESTART_SENSOR";
    static final String ACTION_RELAYOUT = "com.ridehome.RELAYOUT";

    private static final String TAG = "RideHome.Service";
    private static final String CHANNEL = "ridehome_service";
    private static final int NOTIFICATION_ID = 4101;
    private static final int SENSOR_RETRY_SECONDS = 15;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Sampler sampler = new Sampler();
    private final List<int[]> samples = new ArrayList<>();
    private final List<int[]> pre = new ArrayList<>();

    private SensorSource sensor;
    private MetricsOverlay overlay;
    private boolean destroyed;
    private boolean riding;
    private int startStreak;
    private int idleStreak;
    private int ticksSinceCheckpoint;
    private int disconnectedTicks;
    private long rideStartMs;
    private float totalKj;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (destroyed) {
                return;
            }
            try {
                tick();
            } catch (RuntimeException e) {
                Log.e(TAG, "tick failed", e);
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(NOTIFICATION_ID, buildNotification());
        overlay = new MetricsOverlay(this);
        RideStore.recoverCheckpoint(this);
        startSensor();
        handler.postDelayed(ticker, 1000);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_RESTART_SENSOR.equals(action)) {
            startSensor();
        } else if (ACTION_RELAYOUT.equals(action) && riding) {
            overlay.show(barAtTop());
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        destroyed = true;
        handler.removeCallbacks(ticker);
        if (riding) {
            finishRide();
        }
        stopSensor();
        overlay.hide();
        Live.riding = false;
        super.onDestroy();
    }

    // ---------------------------------------------------------------- sensor

    private void startSensor() {
        stopSensor();
        boolean notPeloton = !"Peloton".equalsIgnoreCase(Build.BRAND);
        boolean demo = notPeloton || prefs().getBoolean(Cfg.KEY_DEMO, false);
        Live.demo = demo;
        sampler.reset();
        sensor = demo ? new DemoSensor() : new AffernetSensor(getApplicationContext());
        sensor.start(sampler);
        disconnectedTicks = 0;
    }

    private void stopSensor() {
        if (sensor != null) {
            sensor.stop();
            sensor = null;
        }
    }

    // ------------------------------------------------------------------ tick

    private void tick() {
        Live.overlayAllowed = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        boolean connected = sensor != null && sensor.isConnected();
        Live.sensorConnected = connected;

        if (!connected && !Live.demo) {
            disconnectedTicks++;
            if (disconnectedTicks >= SENSOR_RETRY_SECONDS) {
                Log.i(TAG, "bike sensor not connected, retrying");
                startSensor();
            }
        } else {
            disconnectedTicks = 0;
        }

        Sampler.Snap snap = sampler.snapshot(SystemClock.elapsedRealtime());
        float cadence = snap.live ? snap.cadence : 0f;
        float watts = snap.live ? snap.power : 0f;
        float resistance = snap.resistance;
        int[] sample = {Math.round(cadence), Math.round(resistance), Math.round(watts)};

        Live.cadence = sample[0];
        Live.resistance = sample[1];
        Live.power = sample[2];

        if (!riding) {
            if (cadence >= Cfg.PEDAL_START_RPM) {
                pre.add(sample);
                startStreak++;
                if (startStreak >= Cfg.PEDAL_START_SECONDS) {
                    beginRide();
                }
            } else {
                pre.clear();
                startStreak = 0;
            }
        } else {
            samples.add(sample);
            totalKj += sample[2] / 1000f;
            if (cadence >= Cfg.PEDAL_STOP_RPM) {
                idleStreak = 0;
            } else {
                idleStreak++;
            }
            if (idleStreak >= Cfg.IDLE_END_SECONDS) {
                finishRide();
            } else {
                ticksSinceCheckpoint++;
                if (ticksSinceCheckpoint >= Cfg.CHECKPOINT_SECONDS) {
                    ticksSinceCheckpoint = 0;
                    RideStore.writeCheckpoint(this, rideStartMs, samples);
                }
            }
        }

        Live.elapsedSec = riding ? samples.size() : 0;
        if (riding) {
            overlay.update(samples.size(), sample[0], sample[1], sample[2], totalKj);
        }
        Live.status = describeStatus();
    }

    private void beginRide() {
        riding = true;
        idleStreak = 0;
        ticksSinceCheckpoint = 0;
        samples.clear();
        samples.addAll(pre);
        pre.clear();
        startStreak = 0;
        totalKj = 0f;
        for (int[] s : samples) {
            totalKj += s[2] / 1000f;
        }
        rideStartMs = System.currentTimeMillis() - samples.size() * 1000L;
        Live.riding = true;
        overlay.show(barAtTop());
        Log.i(TAG, "ride started");
    }

    private void finishRide() {
        riding = false;
        Live.riding = false;
        overlay.hide();

        // Drop the idle tail that triggered the end of the ride.
        int keep = samples.size() - idleStreak;
        if (keep >= Cfg.MIN_RIDE_SECONDS) {
            List<int[]> finished = new ArrayList<>(samples.subList(0, keep));
            try {
                RideStore.save(this, rideStartMs, finished);
                Log.i(TAG, "ride saved, " + keep + " s");
            } catch (Exception e) {
                Log.e(TAG, "could not save ride", e);
            }
        } else {
            Log.i(TAG, "ride too short, discarded");
        }
        RideStore.clearCheckpoint(this);
        samples.clear();
        idleStreak = 0;
        startStreak = 0;
        totalKj = 0f;
    }

    // --------------------------------------------------------------- helpers

    private String describeStatus() {
        String base;
        if (Live.demo) {
            base = "Demo mode (simulated bike)";
        } else if (Live.sensorConnected) {
            base = "Bike connected";
        } else {
            base = "Looking for the bike...";
        }
        return base;
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE);
    }

    private boolean barAtTop() {
        return prefs().getBoolean(Cfg.KEY_BAR_TOP, false);
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "Ride Home", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(channel);
            builder = new Notification.Builder(this, CHANNEL);
        } else {
            builder = new Notification.Builder(this);
        }
        Intent open = new Intent(this, LauncherActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT);
        return builder
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("Ride Home")
                .setContentText("Tracking rides")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }
}
