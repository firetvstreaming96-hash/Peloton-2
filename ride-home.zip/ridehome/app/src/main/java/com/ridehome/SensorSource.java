package com.ridehome;

/** A source of bike readings. */
interface SensorSource {
    interface Listener {
        /** Called from any thread. Cadence in rpm, power in watts, resistance 0-100. */
        void onSample(float cadence, float watts, float resistance);
    }

    void start(Listener listener);

    void stop();

    /** True when the source is bound and registered (not necessarily sending data). */
    boolean isConnected();
}
