package com.ridehome;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;

/**
 * Reads the original Peloton Bike's sensors through the tablet's own sensor
 * service (com.onepeloton.affernetservice). The protocol was worked out by the
 * grupetto and Pelomon projects; this is an independent implementation of it.
 *
 * It is an undocumented interface. A Peloton software update can change it.
 */
final class AffernetSensor implements SensorSource {
    private static final String TAG = "RideHome.Sensor";

    private static final String SERVICE_ACTION = "com.onepeloton.affernetservice.IV1Interface";
    private static final String SERVICE_PACKAGE = "com.onepeloton.affernetservice";
    private static final String INTERFACE_DESCRIPTOR = "com.onepeloton.affernetservice.IV1Interface";
    private static final String CALLBACK_DESCRIPTOR = "com.onepeloton.affernetservice.IV1Callback";
    private static final int REGISTER_CODE = 1;
    private static final int UNREGISTER_CODE = 2;
    private static final String CLIENT_NAME = "RideHome";

    private final Context context;
    private volatile Listener listener;
    private IBinder service;
    private boolean bound;
    private volatile boolean registered;

    AffernetSensor(Context context) {
        this.context = context;
    }

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            Log.i(TAG, "sensor service connected");
            if (binder == null) {
                registered = false;
                return;
            }
            service = binder;
            registered = register(binder);
            Log.i(TAG, "registered=" + registered);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.i(TAG, "sensor service disconnected");
            registered = false;
            service = null;
        }
    };

    /** Receives BikeData parcels pushed by the bike's service. */
    private final Binder callback = new Binder() {
        @Override
        protected boolean onTransact(int code, Parcel data, Parcel reply, int flags)
                throws RemoteException {
            if (code == 1) {
                try {
                    data.enforceInterface(CALLBACK_DESCRIPTOR);
                    int hasData = data.readInt();
                    if (hasData != 0) {
                        // First fields of the BikeData parcel, in order.
                        long rpm = data.readLong();
                        long power = data.readLong();
                        data.readLong(); // stepper motor position
                        data.readLong(); // load cell reading
                        int currentResistance = data.readInt();
                        Listener l = listener;
                        if (l != null) {
                            l.onSample((float) rpm, power / 100.0f, (float) currentResistance);
                        }
                    }
                    return true;
                } catch (RuntimeException e) {
                    Log.w(TAG, "bad sensor parcel", e);
                    return false;
                }
            }
            if (code == 2 || code == 3) {
                // Error and calibration notifications. Nothing to do.
                return true;
            }
            return super.onTransact(code, data, reply, flags);
        }
    };

    @Override
    public void start(Listener l) {
        listener = l;
        if (bound) {
            return;
        }
        Intent intent = new Intent();
        intent.setAction(SERVICE_ACTION);
        intent.setPackage(SERVICE_PACKAGE);
        try {
            bound = context.bindService(intent, connection, Context.BIND_AUTO_CREATE);
        } catch (RuntimeException e) {
            Log.w(TAG, "bindService failed", e);
            bound = false;
        }
        if (!bound) {
            Log.w(TAG, "bike sensor service not found");
        }
    }

    @Override
    public void stop() {
        listener = null;
        IBinder svc = service;
        if (svc != null && registered) {
            unregister(svc);
        }
        registered = false;
        service = null;
        if (bound) {
            try {
                context.unbindService(connection);
            } catch (RuntimeException e) {
                Log.w(TAG, "unbind failed", e);
            }
            bound = false;
        }
    }

    @Override
    public boolean isConnected() {
        return registered;
    }

    private boolean register(IBinder svc) {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(INTERFACE_DESCRIPTOR);
            data.writeStrongBinder(callback);
            data.writeString(CLIENT_NAME);
            boolean ok = svc.transact(REGISTER_CODE, data, reply, 0);
            if (ok) {
                reply.readException();
            }
            return ok;
        } catch (Exception e) {
            Log.w(TAG, "register failed", e);
            return false;
        } finally {
            data.recycle();
            reply.recycle();
        }
    }

    private void unregister(IBinder svc) {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(INTERFACE_DESCRIPTOR);
            data.writeStrongBinder(callback);
            data.writeString(CLIENT_NAME);
            if (svc.transact(UNREGISTER_CODE, data, reply, 0)) {
                reply.readException();
            }
        } catch (Exception e) {
            Log.w(TAG, "unregister failed", e);
        } finally {
            data.recycle();
            reply.recycle();
        }
    }
}
