package com.ridehome;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Work/rest interval timer with big numbers and beeps. The ride metrics bar
 * floats over this screen on its own, so the layout leaves the bottom clear.
 */
public class IntervalActivity extends Activity {
    private static final int WARM = 0;
    private static final int WORK = 1;
    private static final int REST = 2;

    private static final int BEEP_TICK = 0;
    private static final int BEEP_START = 1;
    private static final int BEEP_DONE = 2;

    private static final String KEY_WORK = "iv_work";
    private static final String KEY_REST = "iv_rest";
    private static final String KEY_ROUNDS = "iv_rounds";
    private static final String KEY_WARM = "iv_warm";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private ToneGenerator tones;

    // Setup screen
    private TextView summary;
    private Stepper workStep;
    private Stepper restStep;
    private Stepper roundStep;
    private Stepper warmStep;

    // Run state
    private final List<int[]> phases = new ArrayList<>(); // {type, seconds, round}
    private boolean running;
    private boolean paused;
    private boolean finished;
    private int index;
    private int rounds;
    private long remainingMs;
    private long lastRealtime;
    private int lastShownSec;

    // Run screen
    private LinearLayout runRoot;
    private TextView phaseLabel;
    private TextView timeLabel;
    private TextView roundLabel;
    private Button pauseButton;
    private Button skipButton;
    private Button stopButton;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running || paused || finished) {
                return;
            }
            long now = SystemClock.elapsedRealtime();
            remainingMs -= now - lastRealtime;
            lastRealtime = now;
            if (remainingMs <= 0) {
                advance(remainingMs);
            }
            if (running && !paused && !finished) {
                int sec = (int) Math.ceil(Math.max(0L, remainingMs) / 1000.0);
                if (sec != lastShownSec) {
                    lastShownSec = sec;
                    timeLabel.setText(Ui.clock(sec));
                    if (sec >= 1 && sec <= 3) {
                        beep(BEEP_TICK);
                    }
                }
                handler.postDelayed(this, 100);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE);
        try {
            tones = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
        } catch (RuntimeException e) {
            tones = null;
        }
        showSetup();
    }

    @Override
    protected void onStop() {
        // Do not keep counting in the background while she is on YouTube.
        if (running && !paused && !finished) {
            togglePause();
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(tick);
        if (tones != null) {
            tones.release();
            tones = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (running) {
            showSetup();
        } else {
            finish();
        }
    }

    // ----------------------------------------------------------------- setup

    private void showSetup() {
        running = false;
        paused = false;
        finished = false;
        handler.removeCallbacks(tick);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Ui.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 28);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        Button back = Ui.button(this, "Back", Ui.GREY, 22);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(back);
        TextView title = Ui.text(this, "Interval Timer", 32, Ui.TEXT, true);
        title.setPadding(Ui.dp(this, 24), 0, 0, 0);
        top.addView(title);
        root.addView(top);

        TextView presetsLabel = Ui.text(this, "Quick picks (work / rest x rounds)", 18, Ui.MUTED, false);
        presetsLabel.setPadding(0, Ui.dp(this, 20), 0, Ui.dp(this, 8));
        root.addView(presetsLabel);

        workStep = new Stepper("Work", prefs.getInt(KEY_WORK, 30), 5, 5, 600, true);
        restStep = new Stepper("Rest", prefs.getInt(KEY_REST, 30), 5, 0, 600, true);
        roundStep = new Stepper("Rounds", prefs.getInt(KEY_ROUNDS, 10), 1, 1, 50, false);
        warmStep = new Stepper("Warm-up", prefs.getInt(KEY_WARM, 0), 30, 0, 600, true);

        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        presets.addView(preset("30 / 30 x 10", 30, 30, 10));
        presets.addView(preset("20 / 10 x 8", 20, 10, 8));
        presets.addView(preset("40 / 20 x 8", 40, 20, 8));
        presets.addView(preset("60 / 60 x 6", 60, 60, 6));
        presets.addView(preset("2:00 / 1:00 x 6", 120, 60, 6));
        root.addView(presets);

        root.addView(spaced(workStep.build()));
        root.addView(spaced(restStep.build()));
        root.addView(spaced(roundStep.build()));
        root.addView(spaced(warmStep.build()));

        summary = Ui.text(this, "", 22, Ui.MUTED, false);
        summary.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 12));
        root.addView(summary);

        Button start = Ui.button(this, "Start", Ui.GREEN, 40);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startRun();
            }
        });
        root.addView(start, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 96)));

        updateSummary();
        setContentView(scroll);
    }

    private Button preset(String label, final int work, final int rest, final int rounds) {
        Button b = Ui.button(this, label, Ui.BLUE, 18);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                workStep.set(work);
                restStep.set(rest);
                roundStep.set(rounds);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        int m = Ui.dp(this, 4);
        lp.setMargins(m, 0, m, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private View spaced(View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 12);
        v.setLayoutParams(lp);
        return v;
    }

    private void updateSummary() {
        if (summary == null || workStep == null || restStep == null
                || roundStep == null || warmStep == null) {
            return;
        }
        int total = warmStep.value + roundStep.value * workStep.value
                + (roundStep.value - 1) * restStep.value;
        summary.setText("Total time: " + Ui.clock(total));
    }

    /** A labelled row with minus and plus buttons. */
    private final class Stepper {
        final String name;
        final int step;
        final int min;
        final int max;
        final boolean isTime;
        int value;
        TextView valueView;

        Stepper(String name, int value, int step, int min, int max, boolean isTime) {
            this.name = name;
            this.step = step;
            this.min = min;
            this.max = max;
            this.isTime = isTime;
            this.value = Math.max(min, Math.min(max, value));
        }

        View build() {
            LinearLayout row = new LinearLayout(IntervalActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackground(Ui.rounded(IntervalActivity.this, Ui.PANEL, 14));
            int p = Ui.dp(IntervalActivity.this, 16);
            row.setPadding(p, p, p, p);

            TextView label = Ui.text(IntervalActivity.this, name, 26, Ui.TEXT, true);
            row.addView(label, new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            Button minus = Ui.button(IntervalActivity.this, "-", Ui.GREY, 30);
            minus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    set(value - step);
                }
            });
            valueView = Ui.text(IntervalActivity.this, format(), 32, Ui.TEXT, true);
            valueView.setGravity(Gravity.CENTER);
            valueView.setMinWidth(Ui.dp(IntervalActivity.this, 150));
            Button plus = Ui.button(IntervalActivity.this, "+", Ui.GREY, 30);
            plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    set(value + step);
                }
            });
            row.addView(minus);
            row.addView(valueView);
            row.addView(plus);
            return row;
        }

        void set(int v) {
            value = Math.max(min, Math.min(max, v));
            if (valueView != null) {
                valueView.setText(format());
            }
            updateSummary();
        }

        String format() {
            if (!isTime) {
                return String.valueOf(value);
            }
            return value == 0 ? "Off" : Ui.clock(value);
        }
    }

    // ------------------------------------------------------------------- run

    private void startRun() {
        int work = workStep.value;
        int rest = restStep.value;
        rounds = roundStep.value;
        int warm = warmStep.value;
        prefs.edit()
                .putInt(KEY_WORK, work)
                .putInt(KEY_REST, rest)
                .putInt(KEY_ROUNDS, rounds)
                .putInt(KEY_WARM, warm)
                .apply();

        phases.clear();
        if (warm > 0) {
            phases.add(new int[] {WARM, warm, 0});
        }
        for (int r = 1; r <= rounds; r++) {
            phases.add(new int[] {WORK, work, r});
            if (r < rounds && rest > 0) {
                phases.add(new int[] {REST, rest, r});
            }
        }

        buildRunView();
        index = 0;
        remainingMs = phases.get(0)[1] * 1000L;
        lastRealtime = SystemClock.elapsedRealtime();
        lastShownSec = -1;
        running = true;
        paused = false;
        finished = false;
        render();
        beep(BEEP_START);
        handler.post(tick);
    }

    private void buildRunView() {
        runRoot = new LinearLayout(this);
        runRoot.setOrientation(LinearLayout.VERTICAL);
        runRoot.setGravity(Gravity.CENTER);
        // Leave room at the bottom for the ride metrics bar.
        runRoot.setPadding(Ui.dp(this, 28), Ui.dp(this, 28), Ui.dp(this, 28), Ui.dp(this, 220));

        phaseLabel = Ui.text(this, "", 64, Ui.TEXT, true);
        phaseLabel.setGravity(Gravity.CENTER);
        runRoot.addView(phaseLabel);

        timeLabel = new TextView(this);
        timeLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 190);
        timeLabel.setTextColor(Ui.TEXT);
        timeLabel.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timeLabel.setGravity(Gravity.CENTER);
        runRoot.addView(timeLabel);

        roundLabel = Ui.text(this, "", 40, Ui.TEXT, false);
        roundLabel.setGravity(Gravity.CENTER);
        runRoot.addView(roundLabel);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);
        buttons.setPadding(0, Ui.dp(this, 24), 0, 0);

        pauseButton = Ui.button(this, "Pause", Ui.GREY, 28);
        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePause();
            }
        });
        skipButton = Ui.button(this, "Skip", Ui.GREY, 28);
        skipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (running && !finished) {
                    advance(0L);
                    lastRealtime = SystemClock.elapsedRealtime();
                }
            }
        });
        stopButton = Ui.button(this, "Stop", Ui.RED, 28);
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSetup();
            }
        });
        buttons.addView(pauseButton, buttonLp());
        buttons.addView(skipButton, buttonLp());
        buttons.addView(stopButton, buttonLp());
        runRoot.addView(buttons);

        setContentView(runRoot);
    }

    private LinearLayout.LayoutParams buttonLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        int m = Ui.dp(this, 10);
        lp.setMargins(m, 0, m, 0);
        return lp;
    }

    private void togglePause() {
        if (!running || finished) {
            return;
        }
        if (paused) {
            paused = false;
            lastRealtime = SystemClock.elapsedRealtime();
            pauseButton.setText("Pause");
            handler.post(tick);
        } else {
            paused = true;
            handler.removeCallbacks(tick);
            pauseButton.setText("Resume");
        }
    }

    /** Moves to the next phase. carry is the (zero or negative) time already overrun. */
    private void advance(long carry) {
        index++;
        if (index >= phases.size()) {
            finishRun();
            return;
        }
        int[] phase = phases.get(index);
        remainingMs = Math.max(1L, phase[1] * 1000L + Math.min(0L, carry));
        lastShownSec = -1;
        render();
        beep(BEEP_START);
    }

    private void finishRun() {
        finished = true;
        handler.removeCallbacks(tick);
        phaseLabel.setText("DONE");
        timeLabel.setText("Nice work");
        timeLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 90);
        roundLabel.setText(rounds + (rounds == 1 ? " round" : " rounds") + " complete");
        runRoot.setBackgroundColor(0xFF2E7D32);
        pauseButton.setVisibility(View.GONE);
        skipButton.setVisibility(View.GONE);
        stopButton.setText("Back");
        beep(BEEP_DONE);
    }

    private void render() {
        int[] phase = phases.get(index);
        int type = phase[0];
        if (type == WARM) {
            phaseLabel.setText("WARM UP");
            runRoot.setBackgroundColor(0xFF37414F);
            roundLabel.setText("Get ready");
        } else if (type == WORK) {
            phaseLabel.setText("WORK");
            runRoot.setBackgroundColor(0xFFC62828);
            roundLabel.setText(String.format(Locale.US, "Round %d of %d", phase[2], rounds));
        } else {
            phaseLabel.setText("REST");
            runRoot.setBackgroundColor(0xFF1565C0);
            roundLabel.setText(String.format(Locale.US, "Next: round %d of %d", phase[2] + 1, rounds));
        }
        timeLabel.setText(Ui.clock((int) Math.ceil(remainingMs / 1000.0)));
    }

    private void beep(int kind) {
        if (tones == null) {
            return;
        }
        try {
            if (kind == BEEP_TICK) {
                tones.startTone(ToneGenerator.TONE_PROP_BEEP, 120);
            } else if (kind == BEEP_START) {
                tones.startTone(ToneGenerator.TONE_PROP_BEEP2, 350);
            } else {
                tones.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 900);
            }
        } catch (RuntimeException ignored) {
            // Audio hiccup. The screen still shows the countdown.
        }
    }
}
