package com.ridehome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * The home screen: three big buttons and nothing else. Long-press the title
 * for a PIN-protected admin menu.
 */
public class LauncherActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status;
    private Button permissionBanner;

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            updateStatus();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        ensureService();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ensureService();
        handler.post(refresh);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refresh);
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        // This is the home screen. Back goes nowhere.
    }

    private void ensureService() {
        Intent i = new Intent(this, RideService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
    }

    // -------------------------------------------------------------------- UI

    private void buildUi() {
        boolean landscape = getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        int pad = Ui.dp(this, 32);
        root.setPadding(pad, pad, pad, pad);

        TextView title = Ui.text(this, "Ride Home", 30, Ui.TEXT, true);
        title.setPadding(0, 0, 0, Ui.dp(this, 20));
        title.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                askPin();
                return true;
            }
        });
        root.addView(title);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        root.addView(row, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        row.addView(tileView("YouTube", "Find a workout", Ui.RED, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openYouTube();
            }
        }, landscape));
        row.addView(tileView("Ride Log", "Your past rides", Ui.BLUE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LauncherActivity.this, RideLogActivity.class));
            }
        }, landscape));
        row.addView(tileView("Interval Timer", "Work and rest rounds", Ui.GREEN,
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(LauncherActivity.this, IntervalActivity.class));
                    }
                }, landscape));

        permissionBanner = Ui.button(this, "Tap here to allow the ride metrics bar", Ui.GREY, 20);
        permissionBanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestOverlayPermission();
            }
        });
        LinearLayout.LayoutParams bannerLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bannerLp.topMargin = Ui.dp(this, 16);
        root.addView(permissionBanner, bannerLp);

        status = Ui.text(this, "", 16, Ui.MUTED, false);
        status.setGravity(Gravity.CENTER_HORIZONTAL);
        status.setPadding(0, Ui.dp(this, 12), 0, 0);
        root.addView(status);

        setContentView(root);
    }

    private Button tileView(String title, String subtitle, int color,
                            View.OnClickListener listener, boolean horizontal) {
        Button b = Ui.tile(this, title, subtitle, color);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = horizontal
                ? new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                : new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        int m = Ui.dp(this, 10);
        lp.setMargins(m, m, m, m);
        b.setLayoutParams(lp);
        return b;
    }

    private void updateStatus() {
        status.setText(Live.status);
        permissionBanner.setVisibility(Live.overlayAllowed ? View.GONE : View.VISIBLE);
    }

    // --------------------------------------------------------------- actions

    private void openYouTube() {
        PackageManager pm = getPackageManager();
        Intent app = pm.getLaunchIntentForPackage("com.google.android.youtube");
        if (app != null) {
            startActivity(app);
            return;
        }
        Uri site = Uri.parse("https://www.youtube.com/");
        Intent chrome = new Intent(Intent.ACTION_VIEW, site);
        chrome.setPackage("com.android.chrome");
        try {
            startActivity(chrome);
            return;
        } catch (ActivityNotFoundException ignored) {
            // Fall through to any browser.
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, site));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No YouTube app or web browser is installed.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void requestOverlayPermission() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this,
                    "Run on a computer: adb shell appops set " + getPackageName()
                            + " SYSTEM_ALERT_WINDOW allow",
                    Toast.LENGTH_LONG).show();
        }
    }

    // ----------------------------------------------------------------- admin

    private void askPin() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this)
                .setTitle("Admin PIN")
                .setView(input)
                .setPositiveButton("OK", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (Cfg.ADMIN_PIN.equals(input.getText().toString().trim())) {
                            showAdminMenu();
                        } else {
                            Toast.makeText(LauncherActivity.this, "Wrong PIN",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showAdminMenu() {
        final SharedPreferences prefs = getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE);
        final boolean barTop = prefs.getBoolean(Cfg.KEY_BAR_TOP, false);
        final boolean demo = prefs.getBoolean(Cfg.KEY_DEMO, false);
        String[] items = {
                "Open the Peloton home screen",
                "Android settings",
                "Metrics bar position: " + (barTop ? "TOP (tap for bottom)" : "BOTTOM (tap for top)"),
                "Demo mode (simulated bike): " + (demo ? "ON (tap to turn off)" : "OFF (tap to turn on)"),
                "Restart the bike sensor",
                "Allow metrics bar (overlay permission)"
        };
        new AlertDialog.Builder(this)
                .setTitle("Admin")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                openOtherHome();
                                break;
                            case 1:
                                startActivity(new Intent(Settings.ACTION_SETTINGS));
                                break;
                            case 2:
                                prefs.edit().putBoolean(Cfg.KEY_BAR_TOP, !barTop).apply();
                                sendToService(RideService.ACTION_RELAYOUT);
                                break;
                            case 3:
                                prefs.edit().putBoolean(Cfg.KEY_DEMO, !demo).apply();
                                sendToService(RideService.ACTION_RESTART_SENSOR);
                                break;
                            case 4:
                                sendToService(RideService.ACTION_RESTART_SENSOR);
                                break;
                            default:
                                requestOverlayPermission();
                                break;
                        }
                    }
                })
                .show();
    }

    private void sendToService(String action) {
        Intent i = new Intent(this, RideService.class);
        i.setAction(action);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
    }

    /** Opens whichever other home app is installed (normally the stock Peloton one). */
    private void openOtherHome() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        List<ResolveInfo> homes = getPackageManager().queryIntentActivities(home, 0);
        for (ResolveInfo info : homes) {
            if (!getPackageName().equals(info.activityInfo.packageName)) {
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_HOME);
                i.setClassName(info.activityInfo.packageName, info.activityInfo.name);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return;
            }
        }
        Toast.makeText(this, "No other home app found.", Toast.LENGTH_LONG).show();
    }
}
