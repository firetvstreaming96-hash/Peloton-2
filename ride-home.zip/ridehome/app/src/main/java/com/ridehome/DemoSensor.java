package com.ridehome;

import android.os.Handler;
import android.os.Looper;

import java.util.Random;

/**
 * Simulated bike for testing on a phone or an emulator, or on the bike with
 * demo mode on. It pedals for 100 seconds, rests for 60, and repeats, so the
 * overlay, ride detection, and ride log can all be exercised.
 */
final class DemoSensor implements SensorSource {
    private static final int PEDAL_SECONDS = 100;
    private static final int REST_SECONDS = 60;
    private static final long STEP_MS = 250;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private Listener listener;
    private boolean running;
    private long step;

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            if (!running) {
                return;
            }
            Listener l = listener;
            if (l != null) {
                double seconds = step * STEP_MS / 1000.0;
                double cycle = seconds % (PEDAL_SECONDS + REST_SECONDS);
                float cadence = 0f;
                float resistance = 20f;
                float watts = 0f;
                if (cycle < PEDAL_SECONDS) {
                    cadence = (float) (88 + 8 * Math.sin(seconds / 6.0) + random.nextGaussian());
                    resistance = 35f + 5f * (float) Math.floor(cycle / 25.0);
                    watts = Math.max(0f, cadence * resistance * 0.045f
                            + (float) random.nextGaussian() * 2f);
                }
                l.onSample(cadence, watts, resistance);
            }
            step++;
            handler.postDelayed(this, STEP_MS);
        }
    };

    @Override
    public void start(Listener l) {
        listener = l;
        if (!running) {
            running = true;
            step = 0;
            handler.post(loop);
        }
    }

    @Override
    public void stop() {
        running = false;
        listener = null;
        handler.removeCallbacks(loop);
    }

    @Override
    public boolean isConnected() {
        return running;
    }
}
