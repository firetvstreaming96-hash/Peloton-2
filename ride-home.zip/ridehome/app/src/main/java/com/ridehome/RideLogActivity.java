package com.ridehome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** List of past rides, with a seven-day summary on top. */
public class RideLogActivity extends Activity {
    private final List<RideStore.Ride> rides = new ArrayList<>();
    private final SimpleDateFormat dateFormat =
            new SimpleDateFormat("EEE MMM d, h:mm a", Locale.getDefault());

    private TextView weekly;
    private TextView empty;
    private ListView list;
    private RideAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        int pad = Ui.dp(this, 28);
        root.setPadding(pad, pad, pad, pad);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        Button back = Ui.button(this, "Back", Ui.GREY, 22);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(back);
        TextView title = Ui.text(this, "Ride Log", 32, Ui.TEXT, true);
        title.setPadding(Ui.dp(this, 24), 0, 0, 0);
        top.addView(title);
        root.addView(top);

        weekly = Ui.text(this, "", 20, Ui.MUTED, false);
        weekly.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 4));
        root.addView(weekly);

        TextView hint = Ui.text(this, "Tap a ride for details. Press and hold to delete it.",
                15, Ui.MUTED, false);
        hint.setPadding(0, 0, 0, Ui.dp(this, 12));
        root.addView(hint);

        list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(Ui.dp(this, 10));
        list.setSelector(android.R.color.transparent);
        adapter = new RideAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(RideLogActivity.this, RideDetailActivity.class);
                i.putExtra(RideDetailActivity.EXTRA_ID, rides.get(position).id);
                startActivity(i);
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                confirmDelete(rides.get(position));
                return true;
            }
        });
        root.addView(list, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        empty = Ui.text(this, "No rides yet. Start pedaling and your ride will show up here.",
                22, Ui.MUTED, false);
        empty.setGravity(Gravity.CENTER);
        root.addView(empty, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        rides.clear();
        rides.addAll(RideStore.loadAll(this));
        adapter.notifyDataSetChanged();
        list.setVisibility(rides.isEmpty() ? View.GONE : View.VISIBLE);
        empty.setVisibility(rides.isEmpty() ? View.VISIBLE : View.GONE);

        long weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000;
        int count = 0;
        int seconds = 0;
        float kj = 0f;
        for (RideStore.Ride r : rides) {
            if (r.startMs >= weekAgo) {
                count++;
                seconds += r.seconds();
                kj += r.totalKj();
            }
        }
        weekly.setText(String.format(Locale.US, "Last 7 days: %d %s, %s riding, %d kJ",
                count, count == 1 ? "ride" : "rides", Ui.clock(seconds), Math.round(kj)));
    }

    private void confirmDelete(final RideStore.Ride ride) {
        new AlertDialog.Builder(this)
                .setTitle("Delete this ride?")
                .setMessage(dateFormat.format(new Date(ride.startMs)))
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        RideStore.delete(RideLogActivity.this, ride.id);
                        reload();
                    }
                })
                .setNegativeButton("Keep", null)
                .show();
    }

    private final class RideAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rides.size();
        }

        @Override
        public Object getItem(int position) {
            return rides.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            RideStore.Ride r = rides.get(position);
            LinearLayout row = new LinearLayout(RideLogActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackground(Ui.rounded(RideLogActivity.this, Ui.PANEL, 14));
            int p = Ui.dp(RideLogActivity.this, 20);
            row.setPadding(p, p, p, p);

            LinearLayout left = new LinearLayout(RideLogActivity.this);
            left.setOrientation(LinearLayout.VERTICAL);
            left.addView(Ui.text(RideLogActivity.this, dateFormat.format(new Date(r.startMs)),
                    24, Ui.TEXT, true));
            left.addView(Ui.text(RideLogActivity.this,
                    Ui.clock(r.seconds()) + "  |  " + Math.round(r.totalKj()) + " kJ",
                    18, Ui.MUTED, false));
            row.addView(left, new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            row.addView(stat("OUTPUT", r.avgPower() + " W"));
            row.addView(stat("CADENCE", r.avgCadence() + " rpm"));
            row.addView(stat("RESISTANCE", String.valueOf(r.avgResistance())));
            return row;
        }

        private View stat(String label, String value) {
            LinearLayout col = new LinearLayout(RideLogActivity.this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = Ui.dp(RideLogActivity.this, 24);
            col.setLayoutParams(lp);
            col.addView(Ui.text(RideLogActivity.this, value, 24, Ui.TEXT, true));
            col.addView(Ui.text(RideLogActivity.this, label, 13, Ui.MUTED, false));
            return col;
        }
    }
}
