package com.ridehome;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

/** Small helpers so the screens can be built in code without XML. */
final class Ui {
    static final int BG = 0xFF0E1116;
    static final int PANEL = 0xFF1A1F27;
    static final int TEXT = 0xFFFFFFFF;
    static final int MUTED = 0xFF9AA4B2;
    static final int RED = 0xFFD7263D;
    static final int BLUE = 0xFF2A6FDB;
    static final int GREEN = 0xFF1FA35C;
    static final int GREY = 0xFF3A4350;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static GradientDrawable rounded(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    static Button button(Context c, String label, int color, float sp) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(rounded(c, color, 16));
        b.setPadding(dp(c, 24), dp(c, 12), dp(c, 24), dp(c, 12));
        return b;
    }

    /** Big home-screen tile: large title with a smaller subtitle underneath. */
    static Button tile(Context c, String title, String subtitle, int color) {
        Button b = button(c, "", color, 44);
        SpannableStringBuilder sb = new SpannableStringBuilder(title + "\n" + subtitle);
        sb.setSpan(new RelativeSizeSpan(0.42f), title.length() + 1, sb.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        b.setText(sb);
        b.setGravity(Gravity.CENTER);
        return b;
    }

    static String clock(int totalSeconds) {
        int s = Math.max(0, totalSeconds);
        int h = s / 3600;
        int m = (s % 3600) / 60;
        int sec = s % 60;
        if (h > 0) {
            return String.format(Locale.US, "%d:%02d:%02d", h, m, sec);
        }
        return String.format(Locale.US, "%d:%02d", m, sec);
    }
}
