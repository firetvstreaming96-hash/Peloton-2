package com.ridehome;

import android.os.SystemClock;

/**
 * Collects raw sensor callbacks and hands out one smoothed reading per second.
 * Power and cadence are averaged over the second. Resistance is the minimum of
 * the last three readings, which filters the upward spikes the bike's sensor
 * produces (same trick grupetto uses).
 */
final class Sampler implements SensorSource.Listener {

    static final class Snap {
        final boolean live;
        final float cadence;
        final float power;
        final float resistance;

        Snap(boolean live, float cadence, float power, float resistance) {
            this.live = live;
            this.cadence = cadence;
            this.power = power;
            this.resistance = resistance;
        }
    }

    private double sumCadence;
    private double sumPower;
    private int count;

    private final float[] window = new float[3];
    private int windowCount;
    private int windowPos;

    private float heldCadence;
    private float heldPower;
    private float heldResistance;
    private long lastDataAt;

    @Override
    public synchronized void onSample(float cadence, float watts, float resistance) {
        sumCadence += cadence;
        sumPower += watts;
        count++;
        window[windowPos] = resistance;
        windowPos = (windowPos + 1) % window.length;
        if (windowCount < window.length) {
            windowCount++;
        }
        lastDataAt = SystemClock.elapsedRealtime();
    }

    synchronized Snap snapshot(long nowElapsedMs) {
        if (count > 0) {
            heldCadence = (float) (sumCadence / count);
            heldPower = (float) (sumPower / count);
            float min = Float.MAX_VALUE;
            for (int i = 0; i < windowCount; i++) {
                if (window[i] < min) {
                    min = window[i];
                }
            }
            heldResistance = min == Float.MAX_VALUE ? heldResistance : min;
            sumCadence = 0;
            sumPower = 0;
            count = 0;
            return new Snap(true, heldCadence, heldPower, heldResistance);
        }
        if (lastDataAt != 0 && nowElapsedMs - lastDataAt < Cfg.STALE_MS) {
            // The bike may only push on change; hold the last values briefly.
            return new Snap(true, heldCadence, heldPower, heldResistance);
        }
        return new Snap(false, 0f, 0f, heldResistance);
    }

    synchronized void reset() {
        sumCadence = 0;
        sumPower = 0;
        count = 0;
        windowCount = 0;
        windowPos = 0;
        lastDataAt = 0;
    }
}
