package com.ridehome;

/** Live state shared between the background service and the screens. */
final class Live {
    static volatile boolean sensorConnected;
    static volatile boolean overlayAllowed = true;
    static volatile boolean demo;
    static volatile boolean riding;
    static volatile int cadence;
    static volatile int resistance;
    static volatile int power;
    static volatile int elapsedSec;
    static volatile String status = "Starting...";

    private Live() {}
}
