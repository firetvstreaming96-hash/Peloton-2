package com.ridehome;

/** Tunable constants. Change here, rebuild. */
final class Cfg {
    /** PIN for the hidden admin menu (long-press the title on the home screen). */
    static final String ADMIN_PIN = "2580";

    /** A ride starts after this many consecutive seconds at or above PEDAL_START_RPM. */
    static final int PEDAL_START_RPM = 15;
    static final int PEDAL_START_SECONDS = 3;

    /** A ride ends after this many consecutive seconds below PEDAL_STOP_RPM. */
    static final int PEDAL_STOP_RPM = 8;
    static final int IDLE_END_SECONDS = 45;

    /** Rides shorter than this (after trimming the idle tail) are discarded. */
    static final int MIN_RIDE_SECONDS = 60;

    /** In-progress ride is written to disk this often, so a crash loses little. */
    static final int CHECKPOINT_SECONDS = 30;

    /** If no sensor data arrives for this long, readings fall to zero. */
    static final long STALE_MS = 4000;

    static final String PREFS = "ridehome";
    static final String KEY_BAR_TOP = "bar_top";
    static final String KEY_DEMO = "demo";

    private Cfg() {}
}
