package com.ridehome;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/**
 * The ride metrics bar. It floats above every app (including YouTube), ignores
 * touches, and is only on screen while she is riding.
 */
final class MetricsOverlay {
    private final Context context;
    private final WindowManager windowManager;
    private LinearLayout root;
    private TextView time;
    private TextView cadence;
    private TextView resistance;
    private TextView power;
    private TextView total;

    MetricsOverlay(Context context) {
        this.context = context;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
    }

    boolean isShown() {
        return root != null;
    }

    @SuppressWarnings("deprecation")
    void show(boolean atTop) {
        hide();
        build();
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = (atTop ? Gravity.TOP : Gravity.BOTTOM) | Gravity.CENTER_HORIZONTAL;
        lp.y = Ui.dp(context, atTop ? 24 : 56);
        try {
            windowManager.addView(root, lp);
            Live.overlayAllowed = true;
        } catch (RuntimeException e) {
            // Usually: the "draw over other apps" permission has not been granted.
            root = null;
            Live.overlayAllowed = false;
        }
    }

    void hide() {
        if (root != null) {
            try {
                windowManager.removeViewImmediate(root);
            } catch (RuntimeException ignored) {
                // Already gone.
            }
            root = null;
        }
    }

    void update(int seconds, int cadenceRpm, int resistancePct, int watts, float kilojoules) {
        if (root == null) {
            return;
        }
        time.setText(Ui.clock(seconds));
        cadence.setText(String.format(Locale.US, "%d", cadenceRpm));
        resistance.setText(String.format(Locale.US, "%d", resistancePct));
        power.setText(String.format(Locale.US, "%d", watts));
        total.setText(String.format(Locale.US, "%d", Math.round(kilojoules)));
    }

    private void build() {
        root = new LinearLayout(context);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackground(Ui.rounded(context, 0xD9101418, 24));
        int padH = Ui.dp(context, 28);
        int padV = Ui.dp(context, 14);
        root.setPadding(padH, padV, padH, padV);

        time = new TextView(context);
        cadence = new TextView(context);
        resistance = new TextView(context);
        power = new TextView(context);
        total = new TextView(context);

        root.addView(tile(time, "TIME"));
        root.addView(tile(cadence, "CADENCE"));
        root.addView(tile(resistance, "RESISTANCE"));
        root.addView(tile(power, "OUTPUT (W)"));
        root.addView(tile(total, "TOTAL (kJ)"));
        update(0, 0, 0, 0, 0f);
    }

    private LinearLayout tile(TextView value, String label) {
        LinearLayout tile = new LinearLayout(context);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = Ui.dp(context, 18);
        lp.rightMargin = Ui.dp(context, 18);
        tile.setLayoutParams(lp);

        value.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 52);
        value.setTextColor(Ui.TEXT);
        value.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        value.setGravity(Gravity.CENTER);
        value.setMinWidth(Ui.dp(context, 96));

        TextView caption = Ui.text(context, label, 14, Ui.MUTED, false);
        caption.setGravity(Gravity.CENTER);

        tile.addView(value);
        tile.addView(caption);
        return tile;
    }
}
