package com.ridehome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** One ride: headline numbers and a chart. */
public class RideDetailActivity extends Activity {
    static final String EXTRA_ID = "ride_id";

    private String rideId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        rideId = getIntent().getStringExtra(EXTRA_ID);
        RideStore.Ride ride = rideId == null ? null : RideStore.load(this, rideId);
        if (ride == null) {
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        int pad = Ui.dp(this, 28);
        root.setPadding(pad, pad, pad, pad);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        Button back = Ui.button(this, "Back", Ui.GREY, 22);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(back);
        String when = new SimpleDateFormat("EEEE MMM d, h:mm a", Locale.getDefault())
                .format(new Date(ride.startMs));
        TextView title = Ui.text(this, when, 28, Ui.TEXT, true);
        title.setPadding(Ui.dp(this, 24), 0, 0, 0);
        top.addView(title, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button delete = Ui.button(this, "Delete", Ui.RED, 20);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDelete();
            }
        });
        top.addView(delete);
        root.addView(top);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(0, Ui.dp(this, 20), 0, Ui.dp(this, 12));
        stats.addView(stat("TIME", Ui.clock(ride.seconds())));
        stats.addView(stat("TOTAL OUTPUT", Math.round(ride.totalKj()) + " kJ"));
        stats.addView(stat("AVG OUTPUT", ride.avgPower() + " W"));
        stats.addView(stat("MAX OUTPUT", ride.maxPower() + " W"));
        stats.addView(stat("AVG CADENCE", ride.avgCadence() + " rpm"));
        stats.addView(stat("AVG RESISTANCE", String.valueOf(ride.avgResistance())));
        root.addView(stats);

        ChartView chart = new ChartView(this);
        chart.setData(ride.power, ride.cadence, ride.resistance);
        root.addView(chart, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private View stat(String label, String value) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        col.setLayoutParams(lp);
        col.addView(Ui.text(this, value, 30, Ui.TEXT, true));
        col.addView(Ui.text(this, label, 13, Ui.MUTED, false));
        return col;
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Delete this ride?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        RideStore.delete(RideDetailActivity.this, rideId);
                        finish();
                    }
                })
                .setNegativeButton("Keep", null)
                .show();
    }
}
