package com.ridehome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Three stacked line charts for one ride: output, cadence, resistance. */
final class ChartView extends View {
    private int[] power = new int[0];
    private int[] cadence = new int[0];
    private int[] resistance = new int[0];

    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint();
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    ChartView(Context context) {
        super(context);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Ui.dp(context, 2));
        line.setStrokeJoin(Paint.Join.ROUND);
        grid.setColor(0xFF2A313B);
        grid.setStrokeWidth(Ui.dp(context, 1));
        label.setTextSize(Ui.dp(context, 16));
        label.setColor(Ui.MUTED);
    }

    void setData(int[] power, int[] cadence, int[] resistance) {
        this.power = power;
        this.cadence = cadence;
        this.resistance = resistance;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) {
            return;
        }
        float band = h / 3f;
        drawBand(canvas, 0, band, w, "Output (W)", power, 100, 0xFFFFB020);
        drawBand(canvas, band, band, w, "Cadence (rpm)", cadence, 120, 0xFF4DA3FF);
        drawBand(canvas, band * 2, band, w, "Resistance", resistance, 100, 0xFF5AD19A);
    }

    private void drawBand(Canvas canvas, float top, float height, float width,
                          String name, int[] data, int minCeiling, int color) {
        float gap = Ui.dp(getContext(), 14);
        float labelRoom = Ui.dp(getContext(), 22);
        float plotTop = top + labelRoom;
        float plotBottom = top + height - gap;
        float plotHeight = plotBottom - plotTop;

        int max = minCeiling;
        for (int v : data) {
            if (v > max) {
                max = v;
            }
        }

        canvas.drawLine(0, plotBottom, width, plotBottom, grid);
        canvas.drawText(name + "   max " + peak(data), 0, top + labelRoom - Ui.dp(getContext(), 6), label);

        if (data.length < 2 || plotHeight <= 0) {
            return;
        }
        path.reset();
        float step = width / (data.length - 1);
        for (int i = 0; i < data.length; i++) {
            float x = i * step;
            float y = plotBottom - plotHeight * (data[i] / (float) max);
            if (i == 0) {
                path.moveTo(x, y);
            } else {
                path.lineTo(x, y);
            }
        }
        line.setColor(color);
        canvas.drawPath(path, line);
    }

    private static int peak(int[] data) {
        int m = 0;
        for (int v : data) {
            if (v > m) {
                m = v;
            }
        }
        return m;
    }
}
